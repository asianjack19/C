#include <stdio.h>

struct mhs
{
	char name[20];
	int score;
};

struct mhs m;



int main()
{
	
	char nama[6][200];
	int score[6];
	
	for(int i=0; i<6; i++)
	{
		scanf("%s %d", &nama[i], &score[i]);		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
